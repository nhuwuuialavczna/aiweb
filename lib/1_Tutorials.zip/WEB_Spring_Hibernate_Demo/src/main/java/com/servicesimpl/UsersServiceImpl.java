package com.servicesimpl;

import java.util.List;

import com.entities.UsersEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daoapi.UsersDao;
import com.servicesapi.UsersService;

@Service
public class UsersServiceImpl implements UsersService{

	@Autowired
	UsersDao userDao;
	
	public boolean saveOrUpdate(UsersEntity users) {
		return userDao.saveOrUpdate(users);
	}

	public List<UsersEntity> list() {
		// TODO Auto-generated method stub
		return userDao.list();
	}

	public boolean delete(UsersEntity users) {
		// TODO Auto-generated method stub
		return userDao.delete(users);
	}	
	
}

package com.servicesapi;

import com.entities.UsersEntity;

import java.util.List;

public interface UsersService {
	public boolean saveOrUpdate(UsersEntity users);
	public List<UsersEntity> list();
	public boolean delete(UsersEntity users);
}

package com.daoimpl;

import java.util.List;

import com.entities.UsersEntity;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daoapi.UsersDao;


@Repository
@Transactional
public class UsersImpl implements UsersDao{

	@Autowired
	SessionFactory session;
	
	public boolean saveOrUpdate(UsersEntity users) {
		// TODO Auto-generated method stub
		session.getCurrentSession().saveOrUpdate(users);
		return true;
	}

	public List<UsersEntity> list() {
		return session.getCurrentSession().createQuery("from UsersEntity").list();
	}

	public boolean delete(UsersEntity users) {
		try{
			session.getCurrentSession().delete(users);
		}catch(Exception ex){
			return false;
		}
		
		return true;
	}
	
	
}

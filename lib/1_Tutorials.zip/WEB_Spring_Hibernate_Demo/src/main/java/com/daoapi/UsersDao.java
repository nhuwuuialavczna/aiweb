package com.daoapi;

import com.entities.UsersEntity;

import java.util.List;

public interface UsersDao {
	public boolean saveOrUpdate(UsersEntity users);
	public List list();
	public boolean delete(UsersEntity users);
}

package com.boot.service;

import com.boot.model.SinhVien;

import java.util.List;

public interface SinhVienService {
    List<SinhVien> getAll();
    SinhVien getSVByName(String name);
}

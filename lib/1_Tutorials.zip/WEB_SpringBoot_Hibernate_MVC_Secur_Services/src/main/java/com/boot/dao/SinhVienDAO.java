package com.boot.dao;

import com.boot.model.SinhVien;

import java.util.List;

public interface SinhVienDAO {
    List<SinhVien> getAll();

    SinhVien getSVByName(String name);
}

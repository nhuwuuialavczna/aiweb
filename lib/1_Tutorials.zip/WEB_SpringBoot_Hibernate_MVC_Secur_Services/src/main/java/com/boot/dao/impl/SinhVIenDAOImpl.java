package com.boot.dao.impl;

import com.boot.dao.SinhVienDAO;
import com.boot.model.SinhVien;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

@Repository
@Transactional
public class SinhVIenDAOImpl implements SinhVienDAO {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<SinhVien> getAll() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("FROM SinhVien").list();
    }

    @Override
    public SinhVien getSVByName(String name) {
        return getAll().stream().filter(p -> p.getName().equals(name)).findFirst().get();
    }
}

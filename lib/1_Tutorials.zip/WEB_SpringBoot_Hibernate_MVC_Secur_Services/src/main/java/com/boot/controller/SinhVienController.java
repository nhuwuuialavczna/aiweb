package com.boot.controller;

import com.boot.model.SinhVien;
import com.boot.service.SinhVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.List;

@Controller
public class SinhVienController {

    @Autowired
    private SinhVienService sinhVienService;

    @RequestMapping(value = "/sinhviens")
    public @ResponseBody
    List<SinhVien> getAll() {
        System.out.println(sinhVienService.getAll());
        return sinhVienService.getAll();
    }

    @RequestMapping(value = "/get/{name}")
    public @ResponseBody
    SinhVien get(@PathVariable String name) {
        return sinhVienService.getSVByName(name);
    }

    @RequestMapping(value = "/Index")
    public String Index(ModelMap map) {
        map.put("ds", sinhVienService.getAll());
        return "SinhVien";
    }
}

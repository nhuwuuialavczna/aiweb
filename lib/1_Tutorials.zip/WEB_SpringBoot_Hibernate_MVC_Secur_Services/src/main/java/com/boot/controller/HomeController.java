package com.boot.controller;

//import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;

//@RestController
//@RequestMapping(value = "/auth")
public class HomeController {

//    @GetMapping
//    public String sayHi(@AuthenticationPrincipal final UserDetails userDetails) {
//        String username = userDetails.getUsername();
//        String password = userDetails.getPassword();
//
//        System.out.println(username + "\t" + password);
//
//        userDetails.getAuthorities().forEach(System.out::println);
//
//        return "Hi";
//    }
}

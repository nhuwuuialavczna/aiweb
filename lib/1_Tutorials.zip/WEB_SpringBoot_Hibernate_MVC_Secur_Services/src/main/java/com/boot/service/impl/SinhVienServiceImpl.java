package com.boot.service.impl;

import com.boot.dao.SinhVienDAO;
import com.boot.model.SinhVien;
import com.boot.service.SinhVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SinhVienServiceImpl implements SinhVienService {

    @Autowired
    private SinhVienDAO sinhVienDAO;
    @Override
    public List<SinhVien> getAll() {
        return sinhVienDAO.getAll();
    }

    @Override
    public SinhVien getSVByName(String name) {
        return sinhVienDAO.getSVByName(name);
    }
}
